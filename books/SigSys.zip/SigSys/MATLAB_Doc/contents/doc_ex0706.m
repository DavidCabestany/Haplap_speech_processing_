%% Example 7.6
%
%%
% <matlab:edit('ex_7_6a.m') Open the script "ex_7_6a.m" in MATLAB editor> 

%%
% <matlab:ex_7_6a Run the script "ex_7_6a.m"> 

%%
% <matlab:edit('ex_7_6b.m') Open the script "ex_7_6b.m" in MATLAB editor> 

%%
% <matlab:ex_7_6b Run the script "ex_7_6b.m"> 

%%
% $$\textrm{Define an anonymous function for the signal}$$
%
% $$x\left(t\right)=-e^{at}\,u\left(-t\right)$$
%
x = @(t,a) -exp(a*t).*(t<=0);

%%
% $$\textrm{Create a vector of time instants.}$$
%
t = [-4:0.01:1];

%%
% $$\textrm{Compute and graph}\;\;x\left(t\right)\;\;\textrm{for}\;\;a=-0.5$$
%
x1 = x(t,-0.5);
plot(t,x1);

%%
% $$\textrm{Compute and graph}\;\;x\left(t\right)\;\;\textrm{for}\;\;a=0.7$$
%
x2 = x(t,0.7);
plot(t,x2);

%%
% $$\textrm{Compute and graph}\;\;x\left(t\right)\;\;\textrm{for}\;\;a=0.5+j4\textrm{.}$$
%
x3 = x(t,-0.5+j*4);
plot(t,real(x3),t,imag(x3),'--');
legend('Real part','Imag. part');

%%
% $$\textrm{Compute and graph}\;\;x\left(t\right)\;\;\textrm{for}\;\;a=0.7+j4\textrm{.}$$
%
x4 = x(t,0.7+j*4);
plot(t,real(x4),t,imag(x4),'--');
legend('Real part','Imag. part');