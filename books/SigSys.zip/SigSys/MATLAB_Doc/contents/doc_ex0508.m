%% Example 5.16
%
%%
% <matlab:edit('ex_5_16.m') Open the script "ex_5_16.m" in MATLAB editor> 

%%
% <matlab:ex_5_16 Run the script "ex_5_16.m"> 

%%
% $$\textrm{Set parameter}\;\;\alpha\textrm{.}$$
%
alpha = 0.4;

%%
% $$\textrm{Create a vector of angular frequencies.}$$
%
Omg = [-3:0.01:3]*pi;

%%
% $$\textrm{Compute the transform}\;\;X\left(\Omega\right)\textrm{.}$$
%
XOmg = exp(-j*Omg)./(1-alpha*exp(-j*Omg));

%%
% $$\textrm{Graph the magnitude of the transform.}$$
%
plot(Omg,abs(XOmg));
axis([-3*pi,3*pi,0,2]);
xlabel('\Omega (rad)');
ylabel('Magnitude');
title('|X(\Omega)|');
grid;

%%
% $$\textrm{Graph the phase of the transform.}$$
%
plot(Omg,angle(XOmg));
axis([-3*pi,3*pi,-pi,pi]);
xlabel('\Omega (rad)');
ylabel('Phase (rad)');
title('\angle X(\Omega)');
grid;