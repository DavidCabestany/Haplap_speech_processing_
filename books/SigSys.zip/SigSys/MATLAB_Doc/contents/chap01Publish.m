%% Examples
clear all; publish('doc_ex0105.m');
clear all; publish('doc_ex0102.m');
clear all; publish('doc_ex0109.m');
clear all; publish('doc_ex0111.m');
clear all; publish('doc_ex0119.m');
clear all; publish('doc_ex0120.m');

%% MATLAB Exercises
clear all; publish('doc_mex0102.m');
clear all; publish('doc_mex0101.m');
clear all; publish('doc_mex0103.m');
clear all; publish('doc_mex0106.m');
clear all; publish('doc_mex0105.m');
clear all; publish('doc_mex0104.m');
clear all; publish('doc_mex0107.m');

%% TOC
clear all; publish('chap01.m');