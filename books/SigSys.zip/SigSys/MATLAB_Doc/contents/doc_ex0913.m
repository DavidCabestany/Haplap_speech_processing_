%% Example 9.9
%
%%
% <matlab:edit('ex_9_9.m') Open the script "ex_9_9.m" in MATLAB editor> 

%%
% <matlab:ex_9_9 Run the script "ex_9_9.m">

%%
% $$\textrm{Set the state-space model.}$$
%
A = [-2,-1;26,0];
B = [1;0];
C = [-2,0];
d = 1;

%%
% $$\textrm{Enter matrix}\;\;\mathbf{P}\;\;\textrm{and compute its inverse.}$$
%
P = [0,1;26,0];
inv(P)

%%
% $$\textrm{Find the alternative state-space model.}$$
%
A_bar = inv(P)*A*P
B_bar = inv(P)*B
C_bar = C*P