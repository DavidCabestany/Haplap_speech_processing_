%% MATLAB Exercise 4.5
%
%%
% <matlab:edit('matex_4_5.m') Open the script "matex_4_5.m" in MATLAB editor> 

%%
% <matlab:matex_4_5 Run the script "matex_4_5.m">

%%
% $$\textrm{Set parameters}\;\;R\;\;\textrm{and}\;\;C\textrm{.}$$
%
R = 1e6;
C = 1e-6;

%%
% $$\textrm{Compute the critical frequency}\;\;f_{c}$$
%
fc = 1/(2*pi*R*C);

%%
% $$\textrm{Create a vector of frequency values.}$$
%
f = [-500:500]/500;

%%
% $$\textrm{Compute the system function}\;\;H\left(f\right)\textrm{.}$$
%
Hf = 1./(1+j*f/fc);  % Evaluate system function

%%
% $$\textrm{Graph the magnitude of the system function.}$$
%
plot(f,abs(Hf));
axis([-1,1,-0.2,1.2]);
ylabel('Magnitude');
xlabel('Frequency (Hz)');
grid;

%%
% $$\textrm{Graph the phase of the system function.}$$
%
plot(f,angle(Hf));
ylabel('Phase (rad)');
xlabel('Frequency (Hz)');
grid;