%% MATLAB Exercise 5.7
%
%%
% <matlab:edit('matex_5_7.m') Open the script "matex_5_7.m" in MATLAB editor> 

%%
% <matlab:matex_5_7 Run the script "matex_5_7.m"> 

%%
% <matlab:edit('ss_cshift.m') Open the function "ss_cshift.m" in MATLAB editor> 

%%
% <matlab:edit('ss_crev.m') Open the function "ss_crev.m" in MATLAB editor> 

%%
% $$\textrm{Function to do circular shifting:}$$
%
%   function g = ss_cshift(x,m)
%     N = length(x);   % Length of x[n].
%     n = [0:N-1];     % Vector of indices.
%     g = ss_per(x,n-m);
%   end

%%
% $$\textrm{Create a length-N signal and graph it.}$$
%
% $$x[n]\;,\quad n=0,\ldots,9$$
%
n = [0:9];
x = [0,2,3,4,4.5,3,1,-1,2,1];
stem(n,x);

%%
% $$\textrm{Circularly shift the signal by}\;\;m=3\;\;\textrm{samples.}$$
%
% $$g[n] = x[n-3]_{\textrm{mod }10}$$
%
g = ss_cshift(x,3);
stem(n,g);

%%
% $$\textrm{Circularly shift the signal by}\;\;m=-2\;\;\textrm{samples.}$$
%
% $$g[n] = x[n+2]_{\textrm{mod }10}$$
%
g = ss_cshift(x,-2);
stem(n,g);

%%
% $$\textrm{Circular shift by}\;\;m=10\;\;\textrm{should keep the signal unchanged.}$$
%
% $$g[n] = x[n-10]_{\textrm{mod }10}$$
%
g = ss_cshift(x,10);
stem(n,g);

%%
% $$\textrm{Function to do circular time reversal:}$$
%
%   function g = ss_crev(x)
%     N = length(x);   % Length of x[n].
%     n = [0:N-1];     % Vector of indices.
%     g = ss_per(x,-n);
%   end

%%
% $$\textrm{Circular time reversal of the signal:}$$
%
% $$g[n] = x[-n]_{\textrm{mod }10}$$
%
g = ss_crev(x);
stem(n,g);