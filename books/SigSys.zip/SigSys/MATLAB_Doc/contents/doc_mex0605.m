%% MATLAB Exercise 6.5
%
%%
% <matlab:edit('matex_6_5.m') Open the script "matex_6_5.m" in MATLAB editor> 

%%
% <matlab:matex_6_5 Run the script "matex_6_5.m">

%%
% $$\textrm{Define an anonymous function for the transform}\;\;X_{a}\left(f\right)\textrm{.}$$
%
Xa = @(f) 2./(1+4*pi*pi*f.*f);

%%
% $$\textrm{Create a vector of frequencies.}$$
%
f = [-12:0.01:12];

%%
% $$\textrm{Set the sampling rate, the sampling interval and the duty cycle.}$$
%
fs = 3;       % Sampling rate
Ts = 1/fs;    % Sampling interval
d = 0.3;      % Duty cycle

%%
% $$\textrm{Compute the spectrum of zero-order hold sampler output using Eqn. (6.43).}$$
%
Xs = zeros(size(Xa(f)));
for k=-5:5,
  Xs = Xs+fs*Xa(f-k*fs);
end;
Xs = d*Ts*sinc(f*d*Ts).*exp(-j*pi*f*d*Ts).*Xs;

%%
% $$\textrm{Graph the magnitude spectrum of zero-order hold sampler output.}$$
%
plot(f,abs(Xs));
axis([-12,12,-0.1,0.8]);
xlabel('f (Hz)');
title('|X_s(f)|');
grid;