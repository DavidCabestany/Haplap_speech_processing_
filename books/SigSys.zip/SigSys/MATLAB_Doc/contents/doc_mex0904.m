%% MATLAB Exercise 9.2
%
%%
% <matlab:edit('matex_9_2.m') Open the script "matex_9_2.m" in MATLAB editor> 

%%
% <matlab:matex_9_2 Run the script "matex_9_2.m">

%%
% $$\textrm{Set the state-space model.}$$
%
A = [6.5,2,1.5;-10.5,-2,-1.5;5.5,2,2.5];
B = [1;,-2;0];
C = [-1,-1,-2];

%%
% $$\textrm{Compute the matrix}\;\;\mathbf{P}\textrm{.}$$
%
[P,E] = eig(A);

%%
% $$\textrm{Find state-space model with diagonal coefficient matrix.}$$
%
A_bar = inv(P)*A*P
B_bar = inv(P)*B
C_bar = C*P