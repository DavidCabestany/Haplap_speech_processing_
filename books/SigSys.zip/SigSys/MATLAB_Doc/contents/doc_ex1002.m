%% Example 10.2
%
%%
% <matlab:edit('ex_10_2.m') Open the script "ex_10_2.m" in MATLAB editor> 

%%
% <matlab:ex_10_2 Run the script "ex_10_2.m"> 

%%
% $$\textrm{Set parameters.}$$
%
omgc = 20*pi;  % 3-dB cutoff frequency
k = [2:4];     % Indices for the poles in the left half s-plane.

%%
% $$\textrm{Compute poles of the Butterworth filter.}$$
%
pls = omgc*exp(j*2*pi*k/6);

%%
% $$\textrm{Create vectors of frequencies in Hz and rad/s.}$$
%
f = [-25:0.05:25];
omg = 2*pi*f;

%%
% $$\textrm{Compute frequency response using function ss\_freqs(...).}$$
%
[Hmag,Hphs] = ss_freqs([],pls,(20*pi)^3,omg);

%%
% $$\textrm{Graph the magnitude of the frequency response.}$$
%
plot(f,Hmag);
axis([-25,25,0,1.2]);
xlabel('f (Hz)');
ylabel('Magnitude');
title('|H(f)|');
grid;

%%
% $$\textrm{Graph the phase of the frequency response.}$$
%
plot(f,Hphs);
axis([-25,25,-pi,pi]);
xlabel('f (Hz)');
ylabel('Phase');
title('\angle H(f)');
grid;