%% Example 8.35
%
%%
% <matlab:edit('ex_8_35a.m') Open the script "ex_8_35a.m" in MATLAB editor> 

%%
% <matlab:ex_8_35a Run the script "ex_8_35a.m"> 

%%
% <matlab:edit('ex_8_35b.m') Open the script "ex_8_35b.m" in MATLAB editor> 

%%
% <matlab:ex_8_35b Run the script "ex_8_35b.m"> 

%%
% $$\textrm{Define an anonymous function for}\;\;H\left(z\right)\textrm{.}$$
%
H = @(z) (z+1)./(z.*z-5/6*z+1/6);

%%
% $$\textrm{Create a vector of sample indices.}$$
%
n = [-10:20];

%%
% $$\textrm{Compute the input signal.}$$
%
x = (0.9*exp(j*0.2*pi)).^n;

%%
% $$\textrm{Graph the real part of the input signal.}$$
%
stem(n,real(x));
axis([-10.5,20.5,-4,4]);
xlabel('n');
title('Re\{ x[n] \}');

%%
% $$\textrm{Graph the imaginary part of the input signal.}$$
%
stem(n,imag(x));
axis([-10.5,20.5,-4,4]);
xlabel('n');
title('Im\{ x[n] \}');

%%
% $$\textrm{Evaluate the system function for}\;\;z=0.9\,e^{j0.2\pi}\textrm{.}$$
%
Htmp = H(0.9*exp(j*0.2*pi))

%%
% $$\textrm{Compute the output signal.}$$
%
y = Htmp*x;

%%
% $$\textrm{Graph the real part of the output signal.}$$
%
stem(n,real(y));
axis([-10.5,20.5,-15,15]);
xlabel('n');
title('Re\{ y[n] \}');

%%
% $$\textrm{Graph the imaginary part of the output signal.}$$
%
stem(n,imag(y));
axis([-10.5,20.5,-15,15]);
xlabel('n');
title('Im\{ y[n] \}');