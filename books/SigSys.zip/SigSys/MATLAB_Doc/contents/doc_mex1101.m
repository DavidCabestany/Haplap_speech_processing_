%% MATLAB Exercise 11.1
%
%%
% <matlab:edit('matex_11_1.m') Open the script "matex_11_1.m" in MATLAB editor> 

%%
% <matlab:matex_11_1 Run the script "matex_11_1.m"> 

%% 
% $$\textrm{Set parameters.}$$
Ac = 2;       % Carrier amplitude
Mu = 0.7;     % Modulation index
fc = 25000;   % Carrier frequency (in Hz)
fm = 2000;    % Message frequency

%%
% $$\textrm{Create a vector of time instants.}$$
%
t = [0:1e-6:1e-3];

%%
% $$\textrm{Compute the AM signal.}$$
%
x_am = Ac*(1+Mu*cos(2*pi*fm*t)).*cos(2*pi*fc*t);   % Eqn. (11.8)

%%
% $$\textrm{Compute the envelope.}$$
%
x_env = abs(Ac*(1+Mu*cos(2*pi*fm*t)));   % Eqn. (11.9)

%%
% $$\textrm{Graph the AM signal and the envelope.}$$
%
clf;
plot(t,x_am,'-',t,x_env,'m--');
title('Tone modulated AM signal and its envelope');
xlabel('Time (sec)');
ylabel('Amplitude');
legend('AM signal','Envelope');
grid;