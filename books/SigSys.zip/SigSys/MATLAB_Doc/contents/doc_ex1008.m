%% Example 10.7
%
%%
% <matlab:edit('ex_10_7.m') Open the script "ex_10_7.m" in MATLAB editor> 

%%
% <matlab:ex_10_7 Run the script "ex_10_7.m"> 

%%
% $$\textrm{Create vectors for numerator and denominator coefficients of}\;\;
% G(s)=\frac{2}{\left(s+1\right)\,\left(s+2\right)}$$
%
num = [2];
den = [1,3,2];

%%
% $$\textrm{Set a vector of radian frequencies and compute the frequency spectrum}\;\;
% G\left(\omega\right)$$
%
omg = [0:0.01:5];
G = freqs(num,den,omg);

%%
% $$\textrm{Graph the magnitude}\;\;
% \left|G\left(\omega\right)\right|$$
%
plot(omg,abs(G));
axis([0,5,0,1.2]);
xlabel('\omega (rad/s)');
ylabel('Magnitude');
title('|G(\omega)|');
grid;

%%
% $$\textrm{Graph the phase}\;\;
% \angle\;G\left(\omega\right)$$
%
plot(omg,angle(G));
axis([0,5,-pi,pi]);
xlabel('\omega (rad/s)');
ylabel('Phase (rad)');
title('\angle G(\omega)');
grid;

%%
% $$\textrm{Obtain H(z) through bilinear transformation.}$$
%
[numz,denz] = bilinear(num,den,0.5)

%%
% $$\textrm{Set a vector of angular frequencies and compute the frequency spectrum}\;\;
% H\left(\Omega\right)$$
%
Omg = [0:0.001:1]*pi;
H = freqz(numz,denz,Omg);

%%
% $$\textrm{Graph the magnitude}\;\;
% \left|H\left(\Omega\right)\right|$$
%
plot(Omg,abs(H));
axis([0,pi,0,1.2]);
xlabel('\Omega (rad)');
ylabel('Magnitude');
title('|H(\Omega)|');
grid;

%%
% $$\textrm{Graph the phase}\;\;
% \angle\;H\left(\Omega\right)$$
%
plot(Omg,angle(H));
axis([0,pi,-pi,pi]);
xlabel('\Omega (rad)');
ylabel('Phase (rad)');
title('\angle H(\Omega)');
grid;