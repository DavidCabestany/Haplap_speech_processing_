%% Example 3.14
%
%%
% <matlab:edit('ex_3_14.m') Open the script "ex_3_14.m" in MATLAB editor> 

%%
% <matlab:ex_3_14 Run the script "ex_3_14.m">

%%
% $$\textrm{Set parameter "alpha" for the exponential smoother.}$$
%
alpha = 0.1;

%%
% $$\textrm{Create a vector of sample indices.}$$
%
n = [0:49];

%%
% $$\textrm{Compute the forced response for}\;\;y[-1]=2.5$$
%
y = 1.5*((1-alpha).^(n+1))+1;

%%
% $$\textrm{Graph the forced response.}$$
%
stem(n,y);
axis([-0.5,49.5,-0.5,3]);
title('Forced response y(t) of the system of Example 3.14.');
xlabel('Index n'); 
ylabel('Amplitude');