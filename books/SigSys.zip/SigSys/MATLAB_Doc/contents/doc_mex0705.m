%% MATLAB Exercise 7.2
%
%%
% <matlab:edit('matex_7_2a.m') Open the script "matex_7_2a.m" in MATLAB editor> 

%%
% <matlab:matex_7_2a Run the script "matex_7_2a.m"> 

%%
% <matlab:edit('matex_7_2b.m') Open the script "matex_7_2b.m" in MATLAB editor> 

%%
% <matlab:matex_7_2b Run the script "matex_7_2b.m"> 

%%
% $$\textrm{Define an anonymous function for the Laplace transform}$$
%
% $$X\left(s\right)=\frac{s+0.5}{\left(s+0.5\right)^{2}+4\pi^{2}}$$
%
Xs = @(s) (s+0.5)./((s+0.5).^2+4*pi*pi);

%%
% $$\textrm{Create a vector of radian frequencies and compute the Fourier transform}$$
%
% $$\textrm{by evaluating the Laplace transform for}\;\;
% s=j\omega\;\;\textrm{for}\;\;-15<\omega<15\textrm{.}$$
%
omg = [-15:0.05:15];
Xomg = Xs(j*omg);

%%
% $$\textrm{Graph the magnitude of the Fourier transform.}$$
%
plot(omg,abs(Xomg)); grid;

%%
% $$\textrm{Graph the phase of the Fourier transform.}$$
%
plot(omg,angle(Xomg)); grid;

%%
% $$\textrm{Create vectors for the numerator and the denominator of the Laplace transform.}$$
%
num = [1,0.5];
den = [1,1,39.7284];

%%
% $$\textrm{Use function freqs(...) to compute the Fourier transform for}$$
%
% $$-15<\omega<15\textrm{.}$$
%
%omg = [-15:0.05:15];
Xomg = freqs(num,den,omg);

%%
% $$\textrm{Graph the magnitude of the Fourier transform.}$$
%
plot(omg,abs(Xomg),'r'); grid;

%%
% $$\textrm{Graph the phase of the Fourier transform.}$$
%
plot(omg,angle(Xomg),'r'); grid;