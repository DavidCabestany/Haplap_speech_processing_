%% MATLAB Exercise 2.5
%
%%
% <matlab:edit('matex_2_5a.m') Open the script "matex_2_5a.m" in MATLAB editor> 

%%
% <matlab:matex_2_5a Run the script "matex_2_5a.m"> 

%%
% <matlab:edit('matex_2_5b.m') Open the script "matex_2_5b.m" in MATLAB editor> 

%%
% <matlab:matex_2_5b Run the script "matex_2_5b.m"> 

%%
% <matlab:edit('rc1.m') Open the function "rc1.m" in MATLAB editor> 

%%
% $$\textrm{Create a vector of time instants.}$$
%
t = [0:0.1:1];

%%
% $$\textrm{Compute the exact solution.}$$
%
y = 1-exp(-4*t);   % Eqn.(2.186)

%%
% $$\textrm{Compute the approximate solution using function ode45(...).}$$
%
[t,yhat] = ode45(@rc1,t,0);

%%
% $$\textrm{Graph exact and approximate solutions.}$$
%
plot(t,y,'-',t,yhat,'ro'); grid;
title('Exact and approximate solutions for RC circuit');
xlabel('Time (sec)');
ylabel('Amplitude');
legend('Exact solution','Approximate solution',...
  'Location','SouthEast');

%%
% $$\textrm{Compute and graph the percent approximation error.}$$
%
err_pct = (yhat-y')./y'*100;
plot(t(2:max(size(t))),err_pct(2:max(size(t))),'ro'); grid
title('Percent approximation error');
xlabel('Time (sec)');
ylabel('Percent error');