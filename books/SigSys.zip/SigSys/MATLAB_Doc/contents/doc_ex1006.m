%% Example 10.5
%
%%
% <matlab:edit('ex_10_5a.m') Open the script "ex_10_5a.m" in MATLAB editor> 

%%
% <matlab:ex_10_5a Run the script "ex_10_5a.m"> 

%%
% <matlab:edit('ex_10_5b.m') Open the script "ex_10_5b.m" in MATLAB editor> 

%%
% <matlab:ex_10_5b Run the script "ex_10_5b.m"> 

%%
% $$\textrm{Set vectors numerator and denominator polynomials.}$$
%
num = [0.625];
den = [1,1.1542,1.4161,0.625];

%%
% $$\textrm{Find a partial fraction expansion for G(s).}$$
%
% $$\textrm{See Eqn. (10.133).}$$
%
[r,p,k] = residue(num,den)

%%
% $$\textrm{Convert poles of G(s) to poles of H(z) and find a partial fraction
% expansion for H(z).}$$
%
% $$\textrm{See Eqn. (10.136).}$$
%
T = 0.2;      % Sampling interval
r = r*T       % Residues
p = exp(p*T)  % Poles of H(z)

%%
% $$\textrm{Form}\;\;H\left(z\right)\textrm{.}$$
%
[num1,den1] = residue(r,p,k)

%%
% $$\textrm{Compute the magnitude of the frequency response}\;\;
% \left|H\left(\Omega\right)\right|$$
%
Omega = [0:0.001:1]*pi;
HMag = abs(freqz(num1,den1,Omega));

%%
% $$\textrm{Graph the magnitude}\;\;\left|H\left(\Omega\right)\right|$$
%
plot(Omega,HMag);
axis([0,pi,0,1.2]);
xlabel('\Omega (rad)');
ylabel('Magnitude');
title('|H(\Omega)|');
grid;

%%
% $$\textrm{For a different approach, compute the frequency response}$$
%
% $$\textrm{from the system function H(z) found in Example 10.5.}$$
%
Hz = @(z) (0.0023073*z.*z+0.0021365*z)./(z.*z.*z-2.7412*z.*z+2.5395*z-0.7939);
z = exp(j*Omega);
HMag2 = abs(Hz(z));
plot(Omega,HMag2,Omega,HMag);
axis([0,pi,0,1.2]);
xlabel('\Omega (rad)');
ylabel('Magnitude');
title('|H(\Omega)|');
grid;

%%
% $$\textrm{For yet another approach, obtain the discrete-time filter using the function impinvar(..).}$$
%
% $$\textrm{Compute and compare magnitude responses of the analog and discrete-time filters.}$$
% 
[numz,denz] = impinvar(num,den,5)
[Ha,Wa] = freqs(num,den,512);
[Hz,Wz] = freqz(numz,denz,512,5);
plot(Wa/(2*pi),abs(Ha),'LineWidth',2);
hold on;
plot(Wz,abs(Hz),'r--');
hold off;
axis([0,2.5,0,1.2]);
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB)');
title('Magnitude Response Comparison');
legend('Analog Filter','Discrete-time Filter');