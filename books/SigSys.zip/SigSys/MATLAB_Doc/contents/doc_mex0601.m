%% MATLAB Exercise 6.1
%
%%
% <matlab:edit('matex_6_1a.m') Open the script "matex_6_1a.m" in MATLAB editor> 

%%
% <matlab:matex_6_1a Run the script "matex_6_1a.m"> 

%%
% <matlab:edit('matex_6_1b.m') Open the script "matex_6_1b.m" in MATLAB editor> 

%%
% <matlab:matex_6_1b Run the script "matex_6_1b.m"> 

%%
% $$\textrm{Create an anonymous function for}\;\;X_{a}\left(f\right)\textrm{.}$$
%
Xa = @(f) 2./(1+4*pi*pi*f.*f);    % Original spectrum

%%
% $$\textrm{Create a vector of frequencies.}$$
%
f = [-3:0.01:3];

%%
% $$\textrm{Set sampling rate and sampling interval.}$$
%
fs = 1;         % Sampling rate
Ts = 1/fs;      % Sampling interval

%%
% $$\textrm{Approximate spectrum of impulse-sampled signal.}
%
Xs = zeros(size(Xa(f)));
for k=-5:5,
  Xs = Xs+fs*Xa(f-k*fs);
end;

%%
% $$\textrm{Graph the original spectrum.}$$
%
plot(f,Xa(f));
axis([-3,3,-0.5,2.5]);
xlabel('f (Hz)');
title('X_{a}(f)');
grid;

%%
% $$\textrm{Graph spectrum of impulse-sampled signal.}$$
%
plot(f,Xs);
axis([-3,3,-0.5,2.5]);
hold on;
for k=-5:5,
  tmp = plot(f,fs*Xa(f-k*fs),'g--');
end; 
hold off;
xlabel('f (Hz)');
title('X_{s}(f)');
grid;