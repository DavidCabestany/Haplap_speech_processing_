%% MATLAB Exercise 11.6
%
%%
% <matlab:edit('matex_11_6.m') Open the script "matex_11_6.m" in MATLAB editor> 

%%
% <matlab:matex_11_6 Run the script "matex_11_6.m"> 

%%
% $$\textrm{Create a vector of time instants.}$$
%
t = [0:999]*1e-6;        

%%
% $$\textrm{Single-tone message signal.}$$
%
msg = cos(2*pi*2000*t);  

%%
% $$\textrm{Set parameter value for Ac=1 and modulation index of 0.5.}$$
%
Bc = 1;
a = 1;
b = 0.25;
x_am = ss_sqlawmod(msg,Bc,25000,1e-6,1,0.25,15000,35000);

%%
% $$\textrm{Compute correct envelope for comparison purposes.}$$
%
x_env = 1+0.5*msg;

%%
% $$\textrm{Graph the synthesized AM signal and correct envelope.}$$
%
clf;
plot(t,x_am,t,x_env);
grid;
title('AM signal synthesis using a square-law modulator');
xlabel('t (sec)');
ylabel('Amplitude');
legend('Synthesized signal','Correct envelope');