%% MATLAB Exercise 10.2
%
%%
% <matlab:edit('ss_chebpol.m') Open the function "ss_chebpol.m" in MATLAB editor> 

%%
% <matlab:edit('matex_10_2a.m') Open the script "matex_10_2a.m" in MATLAB editor> 

%%
% <matlab:matex_10_2a Run the script "matex_10_2a.m"> 

%%
% <matlab:edit('matex_10_2b.m') Open the script "matex_10_2b.m" in MATLAB editor> 

%%
% <matlab:matex_10_2b Run the script "matex_10_2b.m"> 

%%
% $$\textrm{Function ss\_chebpol(...) for finding Chebyshev polynomials.}$$
%
%   function [c] = ss_chebpol(N)
%     if (N==0),
%       c = [1];
%     elseif (N==1),
%       c = [1,0];
%     else
%       cnm1 = [1];
%       cn = [1,0];
%       for i = 2:N,
%         c = 2*conv([1,0],cn)-[0,0,cnm1];
%         cnm1 = cn;
%         cn = c;
%       end;
%     end;    

%%
% $$\textrm{Evaluate Chebyshev polynomials}\;\;
% C_{N}\left(\nu\right)\quad\textrm{for}\;\;N=2,4,6$$
%
nu = [0:0.005:1.5];
c2 = ss_chebpol(2);
p2 = polyval(c2,nu);
c4 = ss_chebpol(4);
p4 = polyval(c4,nu);
c6 = ss_chebpol(6);
p6 = polyval(c6,nu);

%%
% $$\textrm{Graph Chebyshev polynomials}\;\;
% C_{N}\left(\nu\right)\quad\textrm{for}\;\;N=2,4,6$$
%
plot(nu,p2,nu,p4,nu,p6);
axis([0,1.2,-2,12]);
legend('N=2','N=4','N=6','Location','NorthWest');
xlabel('\nu');
ylabel('C_N(\nu)');
title('Chebyshev polynomials for N=2,4,6'); 
grid;

%%
% $$\textrm{Evaluate and graph}\;\;
% \frac{1}{1+0.1\,C_{N}^{2}\left(\nu\right)}\quad\textrm{for}\; N=2,4,6$$
%
mgs2 = 1./(1+0.16*p2.*p2);
mgs4 = 1./(1+0.16*p4.*p4);
mgs6 = 1./(1+0.16*p6.*p6);
plot(nu,mgs2,nu,mgs4,nu,mgs6);
axis([0,1.5,0,1.2]);
legend('N=2','N=4','N=6','Location','NorthEast');
xlabel('\nu');
ylabel('C_N(\nu)');
title('Squared magnitude for Chebyshev filters'); 
grid;