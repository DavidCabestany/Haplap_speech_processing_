%% Example 4.29
%
%%
% <matlab:edit('ex_4_29.m') Open the script "ex_4_29.m" in MATLAB editor> 

%%
% <matlab:ex_4_29 Run the script "ex_4_29.m"> 

%%
% $$\textrm{Set signal parameters}\;\;f_{0}\;\;\textrm{and}\;\;\tau\textrm{.}$$
%
f0 = 5;
tau = 1;

%%
% $$\textrm{Create a vector of time instants and compute the signal.}$$
%
t = [-3:0.01:3];
x = cos(2*pi*f0*t).*((t>=-tau)&(t<=tau));

%%
% $$\textrm{Graph the signal.}$$
%
plot(t,x);
xlabel('t');
title('x(t)');
grid;

%%
% $$\textrm{Create a vector of frequencies.}$$
%
f = [-10:0.02:10];

%%
% $$\textrm{Compute the transform.}$$
%
P = @(f) 2*tau*sinc(2*tau*f);
X = 0.5*P(f-f0)+0.5*P(f+f0);   % Eqn. (4.238)

%%
% $$\textrm{Graph the transform.}$$
%
plot(f,X);
xlabel('f (Hz)');
title('X(f)');
grid;