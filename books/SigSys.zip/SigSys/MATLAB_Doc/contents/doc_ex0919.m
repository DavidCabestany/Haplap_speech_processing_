%% Example 9.19
%
%%
% <matlab:edit('ex_9_19a.m') Open the script "ex_9_19a.m" in MATLAB editor> 

%%
% <matlab:ex_9_19a Run the script "ex_9_19a.m"> 

%%
% <matlab:edit('ex_9_19b.m') Open the script "ex_9_19b.m" in MATLAB editor> 

%%
% <matlab:ex_9_19b Run the script "ex_9_19b.m"> 

%%
% $$\textrm{Set state-space model.}$$
%
A = [0,-0.5;0.25,0.75];
B = [2;1];
C = [3,1];
D = [0];

%%
% $$\textrm{Using symbolic math, compute the resolvent matrix.}$$
%
z = sym('z');
tmp = z*eye(2)-A;
rsm = z*inv(tmp)

%%
% $$\textrm{Find the state transition matrix.}$$
%
phi = iztrans(rsm)

%%
% $$\textrm{Find the z-transform of the state vector. Use Eqn. (9.177).}$$
%
Xz = rsm*[2;0]+rsm*B/(z-1)

%%
% $$\textrm{Find the state vector using inverse z-transform.}$$
%
xn = iztrans(Xz)

%%
% $$\textrm{Find the output signal symbolically.}$$
%
yn = C*xn

%%
% $$\textrm{Evaluate and graph the output signal.}$$
%
n = [0:19];
y = subs(yn,'n',n);
stem(n,y);
xlabel('n');
title('y[n]');