%% Example 2.8
%
%%
% <matlab:edit('ex_2_8.m') Open the script "ex_2_8.m" in MATLAB editor> 

%%
% <matlab:ex_2_8 Run the script "ex_2_8.m"> 

%%
% $$\textrm{Set R=2 megaOhms and C=1 microFarad.}$$
%
R = 2e6;           
C = 1e-6;

%%
% $$\textrm{Create a vector of time instants.}$$
%
t = [-1:0.01:8];

%%
% $$\textrm{Compute the time constant.}$$
%
tau = R*C;

%%
% $$\textrm{Compute and graph the output signal.}$$
%
y = (1-exp(-t/tau)).*(t>=0);
plot([tau,tau],[0,1.2],'r--',t,y,'b-');
axis([-1,8,-0.2,1.2]);
text(tau,-0.05,'\tau');
title('Output signal y(t) for Example 2.8');
xlabel('t (sec)'); 
ylabel('Amplitude');
grid;