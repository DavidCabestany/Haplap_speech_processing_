%% Example 5.8
%
%%
% <matlab:edit('ex_5_8.m') Open the script "ex_5_8.m" in MATLAB editor> 

%%
% <matlab:ex_5_8 Run the script "ex_5_8.m"> 

%%
% $$\textrm{Compute and graph the signal}\;\;x[k]\textrm{.}$$
%
k = [-12:15];
x = ss_per([0,1,2,3,4],k);
stem(k,x);

%%
% $$\textrm{Compute and graph the signal}\;\;h[0-k]\textrm{.}$$
%
hmkp = ss_crev([3,3,-3,-2,-1]);      % This is one period of h[-k]
hmk = ss_per(hmkp,k);                % This is h[-k]
stem(k,hmk);

%%
% $$\textrm{Compute}\;\;y[0]\textrm{.}$$
%
% $$\textrm{Remember MATLAB indices 13 through 17 correspond to}\;\;k=0,\ldots,4\textrm{.}$$
%
y0 = sum(x(13:17).*hmk(13:17))

%%
% $$\textrm{Compute the signal}\;\;h[1-k]\;\;\textrm{and graph along with}\;\;x[k]\textrm{.}$$
%
h1mk = ss_per(ss_cshift(hmkp,1),k);  % This is h[1-k]
stem(k,x);
hold on;
stem(k,h1mk,'r');                    % Show h[1-k] in red
hold off;

%%
% $$\textrm{Compute}\;\;y[1]\textrm{.}$$
%
% $$\textrm{Remember MATLAB indices 13 through 17 correspond to}\;\;k=0,\ldots,4\textrm{.}$$
%
y1 = sum(x(13:17).*h1mk(13:17))

%%
% $$\textrm{Compute the signal}\;\;h[2-k]\;\;\textrm{and graph along with}\;\;x[k]\textrm{.}$$
%
h2mk = ss_per(ss_cshift(hmkp,2),k);  % This is h[2-k]
stem(k,x);
hold on;
stem(k,h2mk,'r');                    % Show h[2-k] in red
hold off;

%%
% $$\textrm{Compute}\;\;y[2]\textrm{.}$$
%
% $$\textrm{Remember MATLAB indices 13 through 17 correspond to}\;\;k=0,\ldots,4\textrm{.}$$
%
y2 = sum(x(13:17).*h2mk(13:17))

%%
% $$\textrm{Compute the signal}\;\;h[3-k]\;\;\textrm{and graph along with}\;\;x[k]\textrm{.}$$
%
h3mk = ss_per(ss_cshift(hmkp,3),k);  % This is h[3-k]
stem(k,x);
hold on;
stem(k,h3mk,'r');                    % Show h[3-k] in red
hold off;

%%
% $$\textrm{Compute}\;\;y[3]\textrm{.}$$
%
% $$\textrm{Remember MATLAB indices 13 through 17 correspond to}\;\;k=0,\ldots,4\textrm{.}$$
%
y3 = sum(x(13:17).*h3mk(13:17))

%%
% $$\textrm{Compute the signal}\;\;h[4-k]\;\;\textrm{and graph along with}\;\;x[k]\textrm{.}$$
%
h4mk = ss_per(ss_cshift(hmkp,4),k);  % This is h[4-k]
stem(k,x);
hold on;
stem(k,h4mk,'r');                    % Show h[4-k] in red
hold off;

%%
% $$\textrm{Compute}\;\;y[4]\textrm{.}$$
%
% $$\textrm{Remember MATLAB indices 13 through 17 correspond to}\;\;k=0,\ldots,4\textrm{.}$$
%
y4 = sum(x(13:17).*h4mk(13:17))

%%
% $$\textrm{Graph the signal}\;\;y[n]\textrm{.}$$
%
ynp = [y0,y1,y2,y3,y4];              % This is one period of y[n]
n = [-12:15];
yn = ss_per(ynp,n);                  % This is y[n]
stem(n,yn);