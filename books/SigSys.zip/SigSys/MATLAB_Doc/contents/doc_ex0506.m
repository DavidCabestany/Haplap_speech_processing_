%% Example 5.5
%
%%
% <matlab:edit('ex_5_5.m') Open the script "ex_5_5.m" in MATLAB editor> 

%%
% <matlab:ex_5_5 Run the script "ex_5_5.m"> 

%%
% $$\textrm{Compute DTFS spectrum for}\;\;N=10\\;textrm{and}\;\;L=2.$$
%
% $$\tilde{c}_{k}=\frac{\sin\left(\frac{\pi k}{N}\left(2L+1\right)\right)}{N\,\sin\left(\frac{\pi k}{N}\right)}$$
%
N = 10;
L = 2;
Omega0 = 2*pi/N;
k = [0:9];
c = sin(Omega0/2*(k+eps)*(2*L+1))./sin(Omega0/2*(k+eps));  % DTFS coefficients
% Compute the envelope (by allowing non-integer values of the index)
k2 = [-0.5:0.01:9.5];
env = sin(Omega0/2*(k2+eps)*(2*L+1))./sin(Omega0/2*(k2+eps));
plot(k2,env,'g--');
hold on;
stem(k,c);
hold off;
axis([-0.5,9.5,-2,6]);

%%
% $$\textrm{Repeat with}\;\;N=20\;\;\textrm{and}\;\;L=2.$$
%
N = 20;
L = 2;
Omega0 = 2*pi/N;
k = [0:19];
c = sin(Omega0/2*(k+eps)*(2*L+1))./sin(Omega0/2*(k+eps));
% Compute the envelope (by allowing non-integer values of the index)
k2 = [-0.5:0.01:19.5];
env = sin(Omega0/2*(k2+eps)*(2*L+1))./sin(Omega0/2*(k2+eps));
plot(k2,env,'g--');
hold on;
stem(k,c);
hold off;
axis([-0.5,19.5,-2,6]);