%% Example 5.2
%
%%
% <matlab:edit('ex_5_2.m') Open the script "ex_5_2.m" in MATLAB editor> 

%%
% <matlab:ex_5_2 Run the script "ex_5_2.m"> 

%%
% $$\textrm{Compute and graph the sinusoidal signal}$$
%
% $$x[n]=\cos\left(0.2\pi n\right)$$
%
n = [-4:14];
Omega0 = 2*pi/10;
x = cos(Omega0*n);
stem(n,x);

%%
% $$\textrm{Compute the signal using its DTFS coefficients.}$$
%
% $$x[n]=\tilde{c}_{1}\,e^{j\left(2\pi/10\right)n}+\tilde{c}_{9}\,e^{j\left(18\pi/10\right)n}$$
%
x = 0.5*exp(j*Omega0*n)+0.5*exp(j*9*Omega0*n);
stem(n,x);