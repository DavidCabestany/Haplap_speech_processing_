%% MATLAB Exercise 8.2
%
%%
% <matlab:edit('matex_8_2a.m') Open the script "matex_8_2a.m" in MATLAB editor> 

%%
% <matlab:matex_8_2a Run the script "matex_8_2a.m"> 

%%
% <matlab:edit('matex_8_2b.m') Open the script "matex_8_2b.m" in MATLAB editor> 

%%
% <matlab:matex_8_2b Run the script "matex_8_2b.m"> 

%%
% $$\textrm{Define an anonymous function for}\;\;X\left(z\right)\textrm{.}$$
%
X = @(z) (z-0.7686)./(z.*z-1.5371*z+0.9025);

%%
% $$\textrm{Create a vector of angular frequencies and evaluate the transform}$$
%
% $$\textrm{on the unit circle.}$$
%
Omg = [-1:0.001:1]*pi;
Xdtft = X(exp(j*Omg));

%%
% $$\textrm{Graph the magnitude of the DTFT.}$$
%
plot(Omg,abs(Xdtft)); grid;

%%
% $$\textrm{Graph the phase of the DTFT.}$$
%
plot(Omg,angle(Xdtft)); grid;


%%
% $$\textrm{For an alternative approach, create vectors for the numerator and}$$
%
% $$\textrm{the denominator of}\;\;X\left(z\right)\textrm{.}$$
%
num = [0,1,-0.7686];
den = [1,-1.5371,0.9025];


%%
% $$\textrm{Compute the DTFT using the function freqz(...).}$$
%
[Xdtft,Omg] = freqz(num,den,Omg);

%%
% $$\textrm{Graph the magnitude of the DTFT.}$$
%
plot(Omg,abs(Xdtft)); grid;

%%
% $$\textrm{Graph the phase of the DTFT.}$$
%
plot(Omg,angle(Xdtft)); grid;