%% Example 2.14
%
%%
% <matlab:edit('ex_2_14.m') Open the script "ex_2_14.m" in MATLAB editor> 

%%
% <matlab:ex_2_14 Run the script "ex_2_14.m"> 

%%
% $$\textrm{Create a vector of time instants.}$$
%
t = [0:0.01:3];

%%
% $$\textrm{Compute and graph the natural response using Eqn. (2.95).}$$
%
yh = 16.5*exp(-2*t)-15*exp(-3*t);
plot(t,yh);
axis([0,3,-1,4]);
title('Natural response y_h(t) for Example 2.14.');
xlabel('t (sec)'); 
ylabel('Amplitude');
grid;