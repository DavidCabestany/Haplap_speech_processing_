%% Example 6.2
%
%%
% <matlab:edit('ex_6_2a.m') Open the script "ex_6_2a.m" in MATLAB editor> 

%%
% <matlab:ex_6_2a Run the script "ex_6_2a.m"> 

%%
% <matlab:edit('ex_6_2b.m') Open the script "ex_6_2b.m" in MATLAB editor> 

%%
% <matlab:ex_6_2b Run the script "ex_6_2b.m"> 

%%
% $$\textrm{Define anonymous functions for the three signals}$$
%
% $$x_{a1}\left(t\right),\;\;x_{a2}\left(t\right),\;\;x_{a3}\left(t\right)\textrm{.}$$
%
xa1 = @(t) cos(2*pi*6*t);
xa2 = @(t) cos(2*pi*10*t);
xa3 = @(t) cos(2*pi*22*t);

%%
% $$\textrm{Create a vector of time instants.}$$
%
t = [-0.2:0.001:0.6];

%%
% $$\textrm{Create a vector of sample indices.}$$
%
n = [-10:10];

%%
% $$T_{s}\;\;\textrm{is the sampling interval.}$$
%
Ts = 1/16;

%% 
% $$\textrm{Graph the signal}\;\;x_{a1}\left(t\right)\textrm{.}$$
%
plot(t,xa1(t));
xlabel('t (sec)');
title('x_{a1}(t)');

%% 
% $$\textrm{Graph the signal}\;\;x_{a2}\left(t\right)\textrm{.}$$
%
plot(t,xa2(t));
xlabel('t (sec)');
title('x_{a2}(t)');

%% 
% $$\textrm{Graph the signal}\;\;x_{a3}\left(t\right)\textrm{.}$$
%
plot(t,xa3(t));
xlabel('t (sec)');
title('x_{a3}(t)');

%%
% $$\textrm{Graph}\;\;x_{a1}\left(t\right)\;\;\textrm{and}\;\;
% x_{a1}\left(nT_{s}\right)\;\;\textrm{together.}$$
%
plot(t,xa1(t),'b-',n*Ts,xa1(n*Ts),'ro');
axis([-0.2,0.6,-1.2,1.2]);
xlabel('t (sec)');
title('x_{a1}(t)  and  x_{a1}(nT_{s})');

%%
% $$\textrm{Graph}\;\;x_{a2}\left(t\right)\;\;\textrm{and}\;\;
% x_{a2}\left(nT_{s}\right)\;\;\textrm{together.}$$
%
plot(t,xa2(t),'b-',n*Ts,xa2(n*Ts),'ro');
axis([-0.2,0.6,-1.2,1.2]);
xlabel('t (sec)');
title('x_{a2}(t)  and  x_{a2}(nT_{s})');

%%
% $$\textrm{Graph}\;\;x_{a3}\left(t\right)\;\;\textrm{and}\;\;
% x_{a3}\left(nT_{s}\right)\;\;\textrm{together.}$$
%
plot(t,xa3(t),'b-',n*Ts,xa3(n*Ts),'ro');
axis([-0.2,0.6,-1.2,1.2]);
xlabel('t (sec)');
title('x_{a3}(t)  and  x_{a3}(nT_{s})');

%%
% $$\textrm{Graph}\;\;x_{a1}\left(t\right)\;\;\textrm{and}\;\;
% x_{a2}\left(t\right)\;\;\textrm{along with}\;\;x_{a3}\left(nT_{s}\right)\textrm{.}$$
%
plot(t,xa1(t),'b-',t,xa2(t),'g-',n*Ts,xa3(n*Ts),'ro');
axis([-0.2,0.6,-1.2,1.2]);
xlabel('t (sec)');
title('x_{a1}(t),  x_{a2}(t)  and  x_{a3}(nT_{s})');