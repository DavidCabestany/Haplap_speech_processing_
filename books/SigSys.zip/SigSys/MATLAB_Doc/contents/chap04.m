%% Chapter 4: Fourier Analysis for Continuous-Time Signals and Systems 
% <<K20894_Cover.png>>
%

%% Examples
% * <./doc_ex0403.html Example 4.3> : Periodic pulse train revisited
% * <./doc_ex0404.html Example 4.4> : Trigonometric Fourier series for a square-wave
% * <./doc_ex0406.html Example 4.6> : Periodic pulse-train revisited
% * <./doc_ex0407.html Example 4.7> : Effects of duty cycle on the spectrum
% * <./doc_ex0408.html Example 4.8> : Spectrum of periodic sawtooth waveform
% * <./doc_ex0409.html Example 4.9> : Spectrum of multitone signal
% * <./doc_ex0411.html Example 4.10> : Spectrum of half-wave rectified sinusoidal signal
% * <./doc_ex0412.html Example 4.12> : Fourier transform of a rectangular pulse
% * <./doc_ex0413.html Example 4.13> : Fourier transform of a rectangular pulse revisited
% * <./doc_ex0415.html Example 4.15> : Fourier transform of a right-sided exponential signal
% * <./doc_ex0416.html Example 4.16> : Fourier transform of a two-sided exponential signal
% * <./doc_ex0417.html Example 4.17> : Fourier transform of a triangular pulse
% * <./doc_ex0418.html Example 4.18> : Fourier transform of the signum function
% * <./doc_ex0421.html Example 4.21> : Another example of using the duality property
% * <./doc_ex0424.html Example 4.24> : Symmetry properties for the transform of right-sided exponential signal
% * <./doc_ex0426.html Example 4.26> : Transform of a pulse with odd symmetry
% * <./doc_ex0428.html Example 4.28> : Time shifting a two-sided exponential signal
% * <./doc_ex0429.html Example 4.29> : Modulated pulse
% * <./doc_ex0430.html Example 4.30> : Working with scaled and shifted pulses
% * <./doc_ex0432.html Example 4.32> : Fourier transform of a trapezoidal pulse
% * <./doc_ex0433.html Example 4.33> : Pulse with trapezoidal spectrum
% * <./doc_ex0434.html Example 4.34> : Transform of a truncated sinusoidal signal
% * <./doc_ex0442.html Example 4.43> : System function for the simple RC circuit
% * <./doc_ex0444.html Example 4.45> : Steady-state response of RC circuit for single-tone input
% * <./doc_ex0445.html Example 4.46> : RC circuit with pulse-train input
% * <./doc_ex0446.html Example 4.47> : Pulse response of RC circuit revisited

%% MATLAB Exercises
% * <./doc_mex0401.html MATLAB Exercise 4.1> : Computing finite-harmonic approximation to pulse train
% * <./doc_mex0402.html MATLAB Exercise 4.2> : Computing multiple approximations to pulse train
% * <./doc_mex0403.html MATLAB Exercise 4.3> : Graphing the line spectrum in Example 4.5
% * <./doc_mex0404.html MATLAB Exercise 4.4> : Line spectrum for Example 4.6
% * <./doc_mex0405.html MATLAB Exercise 4.5> : Graphing system function for RC circuit

%% Interactive demo programs
% * <matlab:appr_demo1 appr_demo1> : Approximation of square-wave using sinusoids
% * <matlab:tfs_demo1 tfs_demo1> : TFS for periodic pulse train
% * <matlab:tfs_demo2 tfs_demo2> : TFS for periodic pulse train with even symmetry
% * <matlab:tfs_demo3 tfs_demo3> : TFS for periodic square-wave signal
% * <matlab:efs_demo1 efs_demo1> : EFS for periodic pulse train with even symmetry
% * <matlab:efs_demo2 efs_demo2> : EFS - Effects of time shifting the signal
% * <matlab:ft_demo1 ft_demo1> : Developing further insight
% * <matlab:ft_demo2 ft_demo2> : Fourier transform of a rectangular pulse
% * <matlab:ft_demo3 ft_demo3> : From rectangular pulse to unit impulse
% * <matlab:ft_demo4 ft_demo4> : Fourier transform of right-sided exponential signal
% * <matlab:ft_demo5 ft_demo5> : Fourier transform of two-sided exponential signal
% * <matlab:ft_demo6 ft_demo6> : Fourier transform of a triangular pulse
% * <matlab:ft_demo7 ft_demo7> : Obtaining Fourier transform of the signum function
% * <matlab:ft_demo8 ft_demo8> : Fourier transform of modulated pulse
% * <matlab:ft_demo9 ft_demo9> : Working with scaled and shifted pulses
% * <matlab:ft_demo10 ft_demo10> : Fourier transform of a trapezoidal pulse
% * <matlab:ft_demo11 ft_demo11> : Pulse with trapezoidal spectrum
% * <matlab:ft_demo12 ft_demo12> : Multiplication property of the Fourier transform
% * <matlab:sf_demo1 sf_demo1> : System function for RC circuit
% * <matlab:sf_demo2 sf_demo2> : Steady-state response of RC circuit
% * <matlab:sf_demo3 sf_demo3> : RC circuit with pulse train input
% * <matlab:sf_demo4 sf_demo4> : Pulse response of RC circuit