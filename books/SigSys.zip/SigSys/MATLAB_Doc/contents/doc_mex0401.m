%% MATLAB Exercise 4.1
%
%%
% <matlab:edit('matex_4_1.m') Open the script "matex_4_1.m" in MATLAB editor> 

%%
% <matlab:matex_4_1 Run the script "matex_4_1.m">

%%
% $$\textrm{Set number of harmonics to be used.}$$
%
m = 4;

%%
% $$\textrm{Create a vector of time instants.}$$
%
t = [-7:0.01:7];

%%
% $$\textrm{Set fundamental frequency}\;\;f_{0}=1/3\;\textrm{Hz and}\;\;\omega_{0}=2\pi f_{0}$$
%
f0 = 1/3;
omega0 = 2*pi*f0;

%%
% $$\textrm{Compute the finite-harmonic approximation.}$$
%
x = 1/3;   % Recall that a0=1/3.
% Start the loop to compute the contribution of each harmonic.
for k = 1:m,
  ak = 1/(pi*k)*sin(k*omega0);
  bk = 1/(pi*k)*(1-cos(k*omega0));
  x = x+ak*cos(k*omega0*t)+bk*sin(k*omega0*t);
end;

%%
% $$\textrm{Graph the resulting approximation to}\;\;x\left(t\right)\textrm{.}$$
%
plot(t,x);
xlabel('Time (sec)');
ylabel('Amplitude');
title('Approximation using m=4'); 
grid;