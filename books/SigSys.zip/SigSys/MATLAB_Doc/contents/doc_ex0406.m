%% Example 4.6
%
%%
% <matlab:edit('ex_4_6.m') Open the script "ex_4_6.m" in MATLAB editor> 

%%
% <matlab:ex_4_6 Run the script "ex_4_6.m"> 

%%
% $$\textrm{Set EFS coefficients}\;\;
% c_{k}\;\;\textrm{for}\;\;k=-20,\ldots,20$$
%
k = [-20:20]+eps;  % Avoid division by zero at k=0.
ck = -1./(j*2*pi*k).*(exp(-j*2*pi*k/3)-1)

%%
% $$\textrm{Graph the magnitude of the line spectrum.}$$
%
stem(k,abs(ck));
xlabel('Harmonic index');
ylabel('Magnitude');
title('|c_{k}|');

%%
% $$\textrm{Graph the phase of the line spectrum.}$$
%
stem(k,angle(ck));
xlabel('Harmonic index');
ylabel('Phase (rad)');
title('\angle c_{k}');