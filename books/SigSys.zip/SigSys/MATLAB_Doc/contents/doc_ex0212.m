%% Example 2.11
%
%%
% <matlab:edit('ex_2_11.m') Open the script "ex_2_11.m" in MATLAB editor> 

%%
% <matlab:ex_2_11 Run the script "ex_2_11.m"> 

%%
% $$\textrm{Set R=1 Ohm and C = 0.25 Farads.}$$
%
R = 1;  
C = 0.25;

%%
% $$\textrm{Create a vector of time instants.}$$
%
t = [0:0.01:3];

%%
% $$\textrm{Initial value of the homogeneous solution.}$$
%
yh0 = 5;
alpha = 1/(R*C);  

%%
% $$\textrm{Compute and graph the homogeneous solution.}$$
%
% $$\textrm{Refer to Section 2.5.3.}$$
%
yh = yh0*exp(-alpha*t);
plot(t,yh);
title('Homogeneous solution y_h(t) for Example 2.11.');
xlabel('t (sec)'); 
ylabel('Amplitude');
grid;