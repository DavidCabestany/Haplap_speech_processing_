%% Example 4.43
%
%%
% <matlab:edit('ex_4_43.m') Open the script "ex_4_43.m" in MATLAB editor> 

%%
% <matlab:ex_4_43 Run the script "ex_4_43.m"> 

%%
% $$\textrm{Set system parameters}\;\;R\;\;\textrm{and}\;\;C\textrm{.}$$
%
R = 1;
C = 1;

%%
% $$\textrm{Create a vector of radian frequency values.}$$
%
omg = [-5:0.01:5];

%%
% $$\textrm{Compute the system function.}$$
%
H = 1./(1+j*omg*R*C);

%%
% $$\textrm{Graph the magnitude of the system function.}$$
%
plot(omg,abs(H));
xlabel('\omega (rad/s)');
ylabel('Magnitude');
title('|H(\omega)|');
grid;

%%
% $$\textrm{Graph the phase of the system function.}$$
%
plot(omg,angle(H));
xlabel('\omega (rad/s)');
ylabel('Phase (rad)');
title('\angle H(\omega)');
grid;