%% MATLAB Exercise 7.1
%
%%
% <matlab:edit('matex_7_1a.m') Open the script "matex_7_1a.m" in MATLAB editor> 

%%
% <matlab:matex_7_1a Run the script "matex_7_1a.m"> 

%%
% <matlab:edit('matex_7_1b.m') Open the script "matex_7_1b.m" in MATLAB editor> 

%%
% <matlab:matex_7_1b Run the script "matex_7_1b.m"> 

%%
% <matlab:edit('matex_7_1c.m') Open the script "matex_7_1c.m" in MATLAB editor> 

%%
% <matlab:matex_7_1c Run the script "matex_7_1c.m"> 

%%
% <matlab:edit('matex_7_1d.m') Open the script "matex_7_1d.m" in MATLAB editor> 

%%
% <matlab:matex_7_1d Run the script "matex_7_1d.m"> 

%%
% $$\textrm{Create a mesh grid of points in the s-plane.}$$
%
[sr,si] = meshgrid([-6:0.3:6],[-15:0.5:15]);
s = sr+j*si;

%%
% $$\textrm{Define an anonymous function for}\;\;X\left(s\right)\textrm{.}$$
%
Xs = @(s) (s+0.5)./((s+0.5).^2+4*pi*pi);

%%
% $$\textrm{Compute the magnitude of the Laplace transform and clip it to a maximum value of 2.}$$
%
XsMag = abs(Xs(s));
XsMag = XsMag.*(XsMag<=2)+2.*(XsMag>2);

%%
% $$\textrm{Graph the magnitude in 3-D.}$$
%
mesh(sr,si,XsMag);
axis([-6,6,-15,15]);

%%
% $$\textrm{Redo the graph after adjusting colors and transparency.}$$
%
shading interp;         % Shading method: Interpolated
colormap copper;        % Specify the color map used.
m1 = mesh(sr,si,XsMag);
axis([-6,6,-15,15]);
% Adjust transparency of surface lines.
set(m1,'EdgeAlpha',0.6','FaceAlpha',0.6);
% Specify x,y,z axis labels.
xlabel('\sigma');
ylabel('j\omega');
zlabel('|X(s)|');
% Specify viewing angles. 
view(gca,[23.5,38]);

%%
% $$\textrm{Contour plot.}$$
%
shading interp;         % Shading method: Interpolated
colormap copper;        % Specify the color map used.
values = [[0:0.04:0.2],[0.3:0.1:2]];   % z-axis value for each contour.
m2 = contour(sr,si,XsMag,values); grid;
axis([-6,6,-15,15]);
% Specify x,y axis labels.
xlabel('\sigma');
ylabel('j\omega');

%%
% $$\textrm{Redo the three-dimensional graph including the Laplace transform}$$
%
% $$\textrm{evaluated on the imaginary axis of the s-plane.}$$
%

% Define the trajectory s=j*omega
omega = [-15:0.01:15];
tr = j*omega;
% Produce a mesh plot and hold it.
shading interp;
colormap copper;
m1 = mesh(sr,si,XsMag);
hold on;
% Superimpose a plot of X(s) magnitude values evaluated on the
% trajectory using 'plot3' function.
m2 = plot3(real(tr),imag(tr),abs(Xs(tr)),'b-','LineWidth',1.5);
hold off;
axis([-6,6,-15,15]);
% Adjust transparency of surface lines.
set(m1,'EdgeAlpha',0.6','FaceAlpha',0.6);
% Specify x,y,z axis labels.
xlabel('\sigma');
ylabel('j\omega');
zlabel('|X(s)|');
% Specify viewing angles. 
view(gca,[23.5,38]);

%%
% $$\textrm{Cut the Laplace transform surface along the imaginary axis of the}$$
%
% $$\textrm{s-plane and display the profile of the cutout.}$$
%

% Define the trajectory s=j*omega
omega = [-15:0.01:15];
tr = j*omega;
% Produce a mesh plot and hold it.
shading interp;
colormap copper;
% Set the surface equal to zero in the right half of the s-plane.
XsMag = XsMag.*(sr<=0);
m1 = mesh(sr,si,XsMag);
hold on;
% Superimpose a plot of X(s) magnitude values evaluated on the
% trajectory using 'plot3' function.
m2 = plot3(real(tr),imag(tr),abs(Xs(tr)),'b-','LineWidth',1.5);
% Stem plot on the trajectory for a painted profile look.
m3 = stem3(real(tr([1:25:3000])),imag(tr([1:25:3000])),abs(Xs(tr([1:25:3000]))));
hold off;
axis([-6,6,-15,15]);
% Adjust transparency of surface lines.
set(m1,'EdgeAlpha',0.6','FaceAlpha',0.6);
% Adjust color of cutout profile.
set(m3,'Marker','none','Color',[0.01,0.74,0.25]);
% Specify x,y,z axis labels.
xlabel('\sigma');
ylabel('j\omega');
zlabel('|X(s)|');
% Specify viewing angles. 
view(gca,[23.5,38]);