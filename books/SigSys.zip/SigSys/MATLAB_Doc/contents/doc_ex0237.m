%% Example 3.12
%
%%
% <matlab:edit('ex_3_12.m') Open the script "ex_3_12.m" in MATLAB editor> 

%%
% <matlab:ex_3_12 Run the script "ex_3_12.m">

%%
% $$\textrm{Create a vector of sample indices.}$$
%
n = [0:49];

%%
% $$\textrm{Compute the natural solution for}$$
%
% $$y[-1]=19\;\;\textrm{and}\;\;y[-2]=53$$
%
yh = 2*(0.5).^n+5*(1/3).^n;

%%
% $$\textrm{Graph the natural response.}$$
%
stem(n,yh);
axis([-0.5,49.5,-1,8]);
title('Natural response y_h(t) of the second-order system of Example 3.12.');
xlabel('Index n'); 
ylabel('Amplitude');