%% MATLAB Exercise 10.9
%
%%
% <matlab:edit('matex_10_9a.m') Open the script "matex_10_9a.m" in MATLAB editor> 

%%
% <matlab:matex_10_9a Run the script "matex_10_9a.m"> 

%%
% <matlab:edit('matex_10_9b.m') Open the script "matex_10_9b.m" in MATLAB editor> 

%%
% <matlab:matex_10_9b Run the script "matex_10_9b.m"> 

%%
% $$\textrm{Set design parameters.}$$
%
T = 1;
Rp = 2;
As = 20;
omg1 = 2/T*tan(0.2*pi/2); 
omg2 = 2/T*tan(0.36*pi/2); 

%%
% $$\textrm{Determine the minimum filter order and the critical frequency for the analog prototype.}$$
%
[N,omgc] = buttord(omg1,omg2,Rp,As,'s')

%%
% $$\textrm{Design the analog prototype.}$$
%
[num,den] = butter(N,omgc,'s')

%%
% $$\textrm{Create a vector of radian frequencies.}$$
%
omg = [0:0.01:5];

%%
% $$\textrm{Compute the frequency response for the analog prototype filter.}$$
%
G = freqs(num,den,omg);

%%
% $$\textrm{Graph the magnitude of the frequency response for the analog prototype filter.}$$
%
plot(omg,abs(G));
axis([0,5,0,1.2]);
xlabel('\omega (rad/s)');
ylabel('Magnitude');
title('|G(\omega)| for the analog prototype');
grid;

%%
% $$\textrm{Convert the analog prototype to a discrete-time filter using bilinear transformation.}$$
%
[numz,denz] = bilinear(num,den,1/T)

%%
% $$\textrm{Create a vector of angular frequencies.}$$
%
Omg = [0:0.01:1]*pi;

%%
% $$\textrm{Compute the frequency response for the discrete-time filter.}$$
%
H = freqz(numz,denz,Omg);

%%
% $$\textrm{Graph the magnitude of the frequency response for the discrete-time filter.}$$
%
plot(Omg,abs(H));
axis([0,pi,0,1.2]);
xlabel('\Omega (rad)');
ylabel('Magnitude');
title('|H(\Omega)| for the discrete-time filter');
grid;