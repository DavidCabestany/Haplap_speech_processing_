%% MATLAB Exercise 5.1
%
%%
% <matlab:edit('ss_dtfs.m') Open the function "ss_dtfs.m" in MATLAB editor> 

%%
% <matlab:edit('ss_invdtfs.m') Open the function "ss_invdtfs.m" in MATLAB editor> 

%% 
% $$\textrm{Function to compute the DTFS coefficients:}$$
%
%   function c = ss_dtfs(x,idx)
%     c = zeros(size(idx)); % Create all-zero vector.
%     N = length(x);        % Period of the signal.
%     for kk = 1:length(idx),
%       k = idx(kk);
%       tmp = 0;
%       for nn = 1:length(x),
%         n = nn-1;         % MATLAB indices start with 1.
%         tmp = tmp+x(nn)*exp(-j*2*pi/N*k*n);
%       end;
%       c(kk) = tmp/N;
%     end;  
%   end

%% 
% $$\textrm{Function to construct a signal from its DTFS coefficients:}$$
% 
%   function x = ss_invdtfs(c,idx)
%     x = zeros(size(idx)); % Create all-zero vector.
%     N = length(c);        % Period of the coefficient set.
%     for nn = 1:length(idx),
%       n = idx(nn);
%       tmp = 0;
%       for kk = 1:length(c),
%         k = kk-1;         % MATLAB indices start with 1.
%         tmp = tmp+c(kk)*exp(j*2*pi/N*k*n);
%       end;
%       x(nn) = tmp;
%     end;  
%   end