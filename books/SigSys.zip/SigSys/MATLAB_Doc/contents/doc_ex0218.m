%% Example 2.16
%
%%
% <matlab:edit('ex_2_16.m') Open the script "ex_2_16.m" in MATLAB editor> 

%%
% <matlab:ex_2_16 Run the script "ex_2_16.m"> 

%%
% $$\textrm{Create a vector of time instants.}$$
%
t = [0:0.01:3];

%%
% $$\textrm{Compute and graph the transient response using Eqn. (2.116).}$$
%
yt = 4*exp(-4*t);
plot(t,yt);
axis([0,3,-4,5.5]);
title('Transient response y_t(t) for Example 2.16');
xlabel('t (sec)'); 
ylabel('Amplitude');
grid;

%%
% $$\textrm{Compute and graph the steady-state response using Eqn. (2.117).}$$
%
yss = cos(8*t)+2*sin(8*t);
plot(t,yss);
axis([0,3,-4,5.5]);
title('Steady-state y_{ss}(t) for Example 2.16');
xlabel('t (sec)'); 
ylabel('Amplitude');
grid;

%%
% $$\textrm{Compute and graph the forced response.}$$
%
y = yt+yss;
plot(t,y);
axis([0,3,-4,5.5]);
title('Forced response y(t)=y_t(t)+y_{ss}(t) for Example 2.16');
xlabel('t (sec)'); 
ylabel('Amplitude');
grid;