%% Example 4.47
%
%%
% <matlab:edit('ex_4_47.m') Open the script "ex_4_47.m" in MATLAB editor> 

%%
% <matlab:ex_4_47 Run the script "ex_4_47.m"> 

%%
% $$\textrm{Set parameters}\;\;f_{c}\;\;\textrm{and}\;\;\tau\textrm{.}$$
%
fc = 80;      % Cutoff frequency for the RC system.
tau = 0.01;   % Pulse width (we will use 10 ms).

%%
% $$\textrm{Define an anonymous function for}\;\;H\left(f\right)\textrm{.}$$
%
H = @(f) 1./(1+j*f/fc);

%%
% $$\textrm{Set a vector of frequency values.}$$
%
f = [-500:500];

%%
% $$\textrm{Graph the system function.}$$
%
subplot(1,2,1);
plot(f,abs(H(f)));
xlabel('f (Hz)');
ylabel('Magnitude');
title('|H(f)|');
subplot(1,2,2);
plot(f,angle(H(f)));
axis([-500,500,-pi,pi]);
xlabel('f (Hz)');
ylabel('Phase (rad)');
title('\angle H(f)');

%%
% $$\textrm{Compute and graph the spectrum for the input signal.}$$
%
X = tau*sinc(f*tau);
subplot(1,2,1);
plot(f,abs(X));
xlabel('f (Hz)');
ylabel('Magnitude');
title('|X(f)|');
subplot(1,2,2);
plot(f,angle(X));
axis([-500,500,-pi,pi]);
xlabel('f (Hz)');
ylabel('Phase (rad)');
title('\angle X(f)');

%%
% $$\textrm{Compute and graph the line spectrum for the output signal.}$$
%
Y = X.*H(f);
subplot(1,2,1);
plot(f,abs(Y));
xlabel('f (Hz)');
ylabel('Magnitude');
title('|Y(f)|');
subplot(1,2,2);
plot(f,angle(Y));
axis([-500,500,-pi,pi]);
xlabel('f (Hz)');
ylabel('Phase (rad)');
title('\angle Y(f)');