% Script: matex_5_3
%
% Test the periodic convolution function.
x = [0,1,2,3,4]
h = [3,3,-3,-2,-1]
y = ss_pconv(x,h)