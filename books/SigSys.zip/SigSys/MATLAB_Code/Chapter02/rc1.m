function ydot = rc1(t,y)
  ydot = -4*y+4;
end