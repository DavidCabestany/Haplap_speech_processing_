% Script : matex_1_6a.m
%
% Compute and graph the signal x1[n].
%
n = [4:8];
x1 = [1.1, 2.5, 3.7, 3.2, 2.6];
stem(n,x1);