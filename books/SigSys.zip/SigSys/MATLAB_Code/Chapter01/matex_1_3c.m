% Script : matex_1_3c.m
%
t = [-10:0.01:10];
h = sigx(-4*t+2);
clf;
plot(t,h);