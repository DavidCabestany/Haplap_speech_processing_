function x = ss_ramp(t)
  x = t.*(t>=0);