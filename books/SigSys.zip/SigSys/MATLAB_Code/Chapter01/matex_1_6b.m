% Script : matex_1_6b.m
%
% Compute and graph the signal x2[n].
%
n = [0:99];
x2 = sin(0.2*n);
stem(n,x2);