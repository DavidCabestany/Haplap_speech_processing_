function x = ss_step(t)
  x = 1*(t>=0);