% Script : matex_1_3b.m
%
t = [-10:0.01:10];
g = sigx(2*t-5);
clf;
plot(t,g);