% Script : ex_3_9.m
%
% Set the parameter "A".
A = 10;
% Set y=1 and iterate through the difference equation.
y = 1;
y = 0.5*(y+A/y)
% Second iteration.
y = 0.5*(y+A/y)
% Third iteration.
y = 0.5*(y+A/y)
% Fourth iteration.
y = 0.5*(y+A/y)
% Fifth iteration.
y = 0.5*(y+A/y)